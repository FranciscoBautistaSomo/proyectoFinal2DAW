package com.retroHIFI.webshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetaversoWebShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetaversoWebShopApplication.class, args);
	}

}
