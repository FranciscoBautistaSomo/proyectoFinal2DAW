package com.retroHIFI.webshop.service;

import java.util.*;

import com.retroHIFI.webshop.model.Categoria;
import com.retroHIFI.webshop.model.Producto;

public interface ICategoriaService {
		List<Categoria> findAll();		
}
