package com.retroHIFI.webshop.service;

import com.retroHIFI.webshop.model.DetalleOrden;

public interface IDetalleOrdenService {
		DetalleOrden save(DetalleOrden detalleOrden);
}
